img2text portable (Windows x64)

Quick start:
1) Unzip this folder.
2) Open cmd in this folder.
3) Run:
   img2text.exe <image-path>

Examples:
- img2text.exe C:\images\doc.png
- img2text.exe C:\images\doc.png --json -o result.json

Offline:
- This package includes local models in .\models\
- It can run without internet access.

Notes:
- If you see missing DLL errors, copy all files from this folder together.
- OCR model currently focuses on Latin alphabet text.
